package com.example.android.quiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* when user press sumbit button it shows correct answer and score. */
    public void sumbit(View view) {
        //calling show method to view the answer
        show();
        // if the button is checked then we considered true and then we call score method
        RadioButton California = (RadioButton) findViewById(R.id.Californa_checkbox);
        boolean isCalifornia = California.isChecked();
        score(isCalifornia);


        RadioButton president = (RadioButton) findViewById(R.id.Trump_checkbox);
        boolean isPresident = president.isChecked();
        score(isPresident);

        CheckBox neigber = (CheckBox) findViewById(R.id.Oregan_checkbox);
        boolean isNeigber = neigber.isChecked();

        CheckBox neigberTwo = (CheckBox) findViewById(R.id.Nevada_Id);
        boolean isNeigberTwo = neigberTwo.isChecked();

        CheckBox neigberThree = (CheckBox) findViewById(R.id.New_York);
        boolean isneigberThree = neigberThree.isChecked();


        CheckBox neigberfourth = (CheckBox) findViewById(R.id.New_Mexico);
        boolean isneigberfourth = neigberfourth.isChecked();


        if (neigber.isChecked() && !neigberThree.isChecked() && !neigberfourth.isChecked() && neigberTwo.isChecked()) {
            count++;
            displayScore(count);
        }

        EditText editTextName = (EditText) findViewById(R.id.name_view);
        String isAnswer = editTextName.getText().toString();
        // Here I use if statement to know if the user entered the correct answer
        if (isAnswer.equals("Sacramento")) {
            count += 1;
            displayScore(count);
        }
    }

    // method to find the score
    private void score(boolean result) {
        if (result) {
            count += 1;
            displayScore(count);
        }

    }

    // displaying the score
    private void displayScore(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.score_view);
        quantityTextView.setText("" + number);
    }

    //displaying the result
    private void show() {
        Toast toast = Toast.makeText(this, "1.Sacramento\n 2. California\n 3.Orgean, Nevada\n 4.Donald Trump\n", Toast.LENGTH_LONG);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 100, 220);
        toast.show();
    }


}
